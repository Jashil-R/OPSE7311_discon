package com.example.part2poe.ui.main_category

import androidx.lifecycle.ViewModel

class MainCategoryViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}