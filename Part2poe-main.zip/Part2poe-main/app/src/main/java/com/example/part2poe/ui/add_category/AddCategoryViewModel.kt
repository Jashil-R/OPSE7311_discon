package com.example.part2poe.ui.add_category

import androidx.lifecycle.ViewModel

class AddCategoryViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}